////Ana Carolina Moda - 1720294 - carolmoda44@gmail.com
////
////Felicia Simplício - 8891666
////feliciasimplicio@hotmail.com
////
////Andrea guazzelli 8909872
////Andreaguazzelli13@gmail.com
////
////Leonardo Lima De Souza 8545832
////leonardo02lima@gmail.com
////
////Daniel Victor Guerra Lins 5353521
////danielguerra.g12@gmail.com////

package com.example.aplicativoapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Timer;

public class MainActivity extends AppCompatActivity {

    SensorManager mSensorManager;
    ListView listView;
    TextView valorSensor;
    List<Sensor> deviceSensor = null;

    ///Sensores///
    String Luminosidade = "";
    String Proximidade = "";
    String Umidade = "";
    String Temperatura = "";

   //Localização

    Map<String,String> dadosEnderoco = new HashMap<>();
    Double latPoint;
    Double longPont;
    Timer timer;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = findViewById(R.id.meussensores);
        valorSensor = findViewById(R.id.dadosensor);
        mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        LUMINOSIDADE();
        PROXIMIDADE();
        UMIDADE();
        TEMPERATURA();

        pedirPermissao();


    }


    public void listarlin(View view) {
    }


    //Classes do sensores e seus metodos*/
    ////////////////////////////////////////////
    class LuzSensor implements SensorEventListener {

        @Override
        public void onSensorChanged(SensorEvent event) {
            float valor = event.values[0];
            Luminosidade = "" + valor;
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {
        }
    }

    public void LUMINOSIDADE() {
        Sensor mLuz;
        mLuz = mSensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);
        mSensorManager.registerListener(new LuzSensor(), mLuz, SensorManager.SENSOR_DELAY_FASTEST);
    }

    ////////////////////////////////////////////
    class ProxSensor implements SensorEventListener {
        @Override
        public void onSensorChanged(SensorEvent event) {
            float valor = event.values[0];
            Proximidade = "" + valor;
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {
        }
    }

    public void PROXIMIDADE() {
        Sensor mProx;
        mProx = mSensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        mSensorManager.registerListener(new ProxSensor(), mProx, SensorManager.SENSOR_DELAY_FASTEST);
    }

    ////////////////////////////////////////////
    class UmiSensor implements SensorEventListener {
        @Override
        public void onSensorChanged(SensorEvent event) {
            float valor = event.values[0];
            Umidade = "" + valor;
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {
        }
    }

    public void UMIDADE() {
        Sensor mUmi;
        mUmi = mSensorManager.getDefaultSensor(Sensor.TYPE_RELATIVE_HUMIDITY);
        mSensorManager.registerListener(new UmiSensor(), mUmi, SensorManager.SENSOR_DELAY_FASTEST);
    }

    ////////////////////////////////////////////
    class TempSensor implements SensorEventListener {

        @Override
        public void onSensorChanged(SensorEvent event) {
            float valor = event.values[0];
            Temperatura = "" + valor;
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {
        }
    }

    public void TEMPERATURA() {
        Sensor mTemp;
        mTemp = mSensorManager.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE);
        mSensorManager.registerListener(new TempSensor(), mTemp, SensorManager.SENSOR_DELAY_FASTEST);
    }

    /*Localização*/

    private void pedirPermissao(){
        if(ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) !=
                PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this,
                        Manifest.permission.ACCESS_COARSE_LOCATION) !=
                        PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(this,
                    new String[]{
                            Manifest.permission.ACCESS_FINE_LOCATION
                    }, 1);
        }
        else
            configurarServico();
    }

    public void configurarServico(){
        try {
            LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            LocationListener locationListener = new LocationListener() {
                @Override
                public void onLocationChanged(Location location) {
                    atualizar(location);
                }

                @Override
                public void onStatusChanged(String provider, int status, Bundle extras) {
                }

                @Override
                public void onProviderEnabled(String provider) {  }

                @Override
                public void onProviderDisabled(String provider) {  }
            };
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
        }catch(SecurityException ex){
        }
    }

    public void atualizar(Location location){
        Double latPoint = location.getLatitude();
        Double longPoint = location.getLongitude();

        Log.i("Sensores", "lat "+latPoint);
        Log.i("Sensores", "lon "+longPoint);

    }

    public String post (final JSONObject data){
        try {
            final URL url = new URL();
            final HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("Content - type", "application/json");

            connection.setRequestMethod("POST");
            connection.setDoInput(true);
            connection.setDoInput(true);

            final OutputStream outputStream = connection.getOutputStream();
            final BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(outputStream), "UTF-8");

            writer.write(data.toString());
            writer.flush();
            writer.close();
            outputStream.close();

            connection.connect();

            final InputStream stream = connection.getInputStream();
            return "Sucesso!";
        } catch (Exception e){
            Log.e("Your tag", "Error", e);
        }
        return null;
    }
    public void listarsensores(View view) {
        deviceSensor = mSensorManager.getSensorList(Sensor.TYPE_ALL);
        listView.setAdapter(new ArrayAdapter<Sensor>(this, android.R.layout.simple_list_item_1,deviceSensor));
    }


    ///Mudar Idioma

    public void mudarPortuguês(View view) {
        setLocale("pt");
    }

    public void mudarInglês(View view) {
        setLocale("en");
    }

    public void mudarFrancês(View view) {
        setLocale("fr");
    }

    public void setLocale(String linguagem){
        Locale meuLocal = new Locale(linguagem);//classe que recebe um lugar qualquer
        Resources res = getResources(); //estou pegando todos os recursos do celular
        DisplayMetrics dm = res.getDisplayMetrics(); //Pegando informações da toda a  tela
        Configuration conf = res.getConfiguration(); //Estou selecionando o botão "Configuração"
        conf.locale = meuLocal;
        Intent intent = new Intent(this, ActivityGPS.class);
        Intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }

    private class ActivityGPS {
    }
}

